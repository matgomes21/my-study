-- --------  << PROJETO Aula 1 Exercicio 2 Evolução 2 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 28/07/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2evolucao2
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
    IF NOT EXISTS aula1exer2evolucao2;

USE aula1exer2evolucao2;

-- TABELAS
CREATE TABLE PESSOA (
    cpf VARCHAR(11) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    senhaAcesso VARCHAR(30) NOT NULL,
    
    CONSTRAINT PESSOA_PK PRIMARY KEY (cpf)
) ENGINE = InnoDB;

CREATE TABLE GERENTE (
    cpf VARCHAR(11) NOT NULL,
    formacaoEscolar VARCHAR(100) NOT NULL,
    email VARCHAR(50) NOT NULL,
    
    CONSTRAINT GERENTE_PK PRIMARY KEY (cpf),
    
    CONSTRAINT GERENTE_UK UNIQUE (email),
    
    CONSTRAINT GERENTE_PESSOA_FK FOREIGN KEY(cpf)
		REFERENCES PESSOA(cpf)
) ENGINE = InnoDB;

CREATE TABLE EMPREGADO (
    matricula INT NOT NULL AUTO_INCREMENT,
    cep INT NOT NULL,
    uf VARCHAR(2) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    
    CONSTRAINT EMPREGADO_PK PRIMARY KEY (matricula),
    
    CONSTRAINT EMPREGADO_PESSOA_FK FOREIGN KEY(cpf)
		REFERENCES PESSOA(cpf)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE AREA (
    idArea INT NOT NULL AUTO_INCREMENT,
    nomeArea VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    
    CONSTRAINT AREA_PK PRIMARY KEY (idArea),
    
    CONSTRAINT AREA_GERENTE_FK FOREIGN KEY (cpf)
		REFERENCES GERENTE(cpf)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE PRODUTO (
    idProduto INT NOT NULL AUTO_INCREMENT,
    nomeProduto VARCHAR(100) NOT NULL,
    precoUnitario INT NOT NULL,
    idArea INT NOT NULL,
    
    CONSTRAINT PRODUTO_PK PRIMARY KEY (idProduto),
    
    CONSTRAINT PRODUTO_AREA_FK FOREIGN KEY (idArea)
		REFERENCES AREA(idArea)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE VENDA (
    idVenda INT NOT NULL AUTO_INCREMENT,
    dtVenda DATETIME NOT NULL,
    matricula INT NOT NULL,
    
    CONSTRAINT VENDA_PK PRIMARY KEY (idVenda),
    
    CONSTRAINT VENDA_EMPREGADO_FK FOREIGN KEY (matricula)
		REFERENCES EMPREGADO (matricula)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE telefone (
    matricula INT NOT NULL,
    telefone VARCHAR(11) NOT NULL,
    CONSTRAINT telefone_UK UNIQUE (telefone),
    
    CONSTRAINT telefone_EMPREGADO_FK FOREIGN KEY (matricula)
		REFERENCES EMPREGADO(matricula)
) ENGINE = InnoDB;

CREATE TABLE possui (
    idVenda INT NOT NULL,
    idProduto INT NOT NULL,
    quantidade INT NOT NULL,
    
    CONSTRAINT possui_VENDA_FK FOREIGN KEY (idVenda)
		REFERENCES VENDA(idVenda),
    CONSTRAINT possui_PRODUTO_FK FOREIGN KEY (idProduto)
		REFERENCES PRODUTO(idProduto)
) ENGINE = InnoDB;