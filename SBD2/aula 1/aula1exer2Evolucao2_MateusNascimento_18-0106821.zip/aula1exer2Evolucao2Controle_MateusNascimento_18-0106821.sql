-- ------------------------------------   << PROJETO Aula 1 Exercício 2 Evolução 2 >>   ---------------------------------------
--
--                                                 SCRIPT DE CONTROLE (DDL)                                                 
-- 
-- Data Criação ...........: 28/07/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2evolucao2
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ------------------------------------------------------------------------------------------------------------------------

CREATE USER 'ADMIN'@'localhost' IDENTIFIED BY 'sbd2adm2';
CREATE USER 'USOU'@'localhost' IDENTIFIED BY 'bdusu2021';

GRANT ALL PRIVILEGES ON aula1exer2evolucao2.* TO 'ADMIN'@'localhost';

GRANT SELECT ON aula1exer2evolucao2.* TO 'USOU'@'localhost';

FLUSH PRIVILEGES;