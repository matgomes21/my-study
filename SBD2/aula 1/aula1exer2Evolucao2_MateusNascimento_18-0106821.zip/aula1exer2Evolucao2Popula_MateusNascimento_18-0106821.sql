-- ------------------------------------------   << PROJETO Aula 1 Exercício 2 Evolução 2  >>   ------------------------------------------
--
--                                                SCRIPT DE POPULAR (DML)
-- 
-- Data Criacao ...........: 28/07/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2evolucao2
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ------------------------------------------------------------------------------------------------------------------------

USE aula1exer2evolucao2;

INSERT INTO PESSOA
  (cpf, nome, senhaAcesso)
VALUES
  ('01374926183','Mateus G. Morte','root1234'),
  ('02274426688','Ana T. Costa','tartaruga29'),
  ('12207452315','Antonio Ramos Nogueira','indianajones'),
  ('55128858049','Claudia Raia Portuguesa','levantoupoeira11'),
  ('67287172003','Vinicius S. Feliciano','senhaforte777'),
  ('70509011055','Alonso Ferdinando Sena','seninha24'),
  ('36194900075','Maia Decartes Cunha','fih2344'),
  ('86572628000','Karol Mendes','kmd2244'),
  ('56447081018','Letícia Barros','boxechines'),
  ('16450367075','Gabriel Silva','gabsilva12'),
  ('79423044000','Fernando Henrique Cardoso','felipelaranja'),
  ('34335004010','Marta Felix','marfelix22');
  
INSERT INTO GERENTE
  (cpf, formacaoEscolar, email)
VALUES
  ('01374926183', 'Ensino Superior Incompleto', 'matdev@gmail.com'),
  ('02274426688', 'Ensino Médio Completo', 'anatcosta@gmail.com'),
  ('12207452315', 'Ensino Superior Completo', 'tonyramos@gmail.com'),
  ('36194900075', 'Ensino Médio Completo', 'mariadecartes@gmail.com'),
  ('86572628000', 'Ensino Médio Completo', 'karolmd@gmail.com'),
  ('56447081018', 'Ensino Médio Completo', 'letbarros@gmail.com');
  
INSERT INTO EMPREGADO
  (cep, uf, cidade, bairro, logradouro, cpf)
VALUES
  (60863635, 'CE', 'Fortaleza', 'Barroso', 'Rua Santo Inácio', '55128858049'),
  (64055265, 'PI', 'Teresina', 'Morada do Sol', 'Avenida Senador Area Leão', '67287172003'),
  (88371120, 'SC', 'Navegantes', 'São Paulo', 'Rua Abdon Cardoso Sacavem', '70509011055'),
  (60710903, 'CE', 'Fortaleza', 'Maraponga', 'Avenida Godofredo Maciel, s/n', '16450367075'),
  (77411090, 'TO', 'Gurupi', 'Vila São José', 'Rua 11', '79423044000'),
  (40150470, 'BA', 'Salvador', 'Graça', 'Travessa Engenheiro Souza Lima', '34335004010');
  
INSERT INTO AREA
  (nomeArea, cpf)
VALUES
  ('Alimento', '01374926183'),
  ('Limpeza', '02274426688'),
  ('Cosméticos', '12207452315'),
  ('Vestimenta', '36194900075'),
  ('Remédio', '86572628000'),
  ('Higiene pessoal', '56447081018');
  
INSERT INTO PRODUTO
  (nomeProduto, precoUnitario, idArea)
VALUES
  ('Veja', 2400, 2),
  ('Banana', 1000, 1),
  ('Perfume', 3000, 3),
  ('Camisa Polo', 1400, 4),
  ('Rivotril', 500, 5),
  ('Pasta de dente', 700, 6);
  
INSERT INTO VENDA
  (dtVenda, matricula)
VALUES
  ('2021-07-26 14:10:20', 1),
  ('2021-05-12 17:23:10', 2),
  ('2021-02-13 20:55:14', 3),
  ('2021-07-10 15:40:02', 4),
  ('2021-05-22 22:30:09', 5),
  ('2021-01-31 18:15:00', 6);
  
INSERT INTO telefone
  (matricula, telefone)
VALUES
  (1, '61996927595'),
  (2, '61999866794'),
  (3, '61999844529'),
  (4, '61994982627'),
  (5, '61997925544'),
  (6, '61984222326');
  
INSERT INTO possui
  (idVenda, idProduto, quantidade)
VALUES
  (1, 1, 10),
  (2, 2, 1),
  (3, 3, 12),
  (4, 4, 5),
  (5, 5, 7),
  (6, 6, 3);
	