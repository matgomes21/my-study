-- ------------------------------------------   << PROJETO Aula 1 Exercício 2  >>   ------------------------------------------
--
--                                                SCRIPT DE POPULAR (DML)
-- 
-- Data Criacao ...........: 26/07/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ------------------------------------------------------------------------------------------------------------------------

USE aula1exer2;

INSERT INTO PESSOA
  (cpf, nome, senhaAcesso)
VALUES
  ('01374926183','Mateus G. Morte','root1234'),
  ('02274426688','Ana T. Costa','tartaruga29'),
  ('12207452315','Antonio Ramos Nogueira','indianajones'),
  ('55128858049','Claudia Raia Portuguesa','levantoupoeira11'),
  ('67287172003','Vinicius S. Feliciano','senhaforte777'),
  ('70509011055','Alonso Ferdinando Sena','seninha24');
  
INSERT INTO GERENTE
  (cpf, formacaoEscolar, email)
VALUES
  ('01374926183', 'Ensino Superior Incompleto', 'matdev@gmail.com'),
  ('02274426688', 'Ensino Médio Completo', 'anatcosta@gmail.com'),
  ('12207452315', 'Ensino Superior Completo', 'tonyramos@gmail.com');
  
INSERT INTO EMPREGADO
  (cep, uf, cidade, bairro, logradouro, cpf)
VALUES
  (60863635, 'CE', 'Fortaleza', 'Barroso', 'Rua Santo Inácio', '55128858049'),
  (64055265, 'PI', 'Teresina', 'Morada do Sol', 'Avenida Senador Area Leão', '67287172003'),
  (88371120, 'SC', 'Navegantes', 'São Paulo', 'Rua Abdon Cardoso Sacavem', '70509011055');
  
INSERT INTO AREA
  (nomeArea, cpf)
VALUES
  ('Alimento', '01374926183'),
  ('Limpeza', '02274426688'),
  ('Cosméticos', '12207452315');
  
INSERT INTO PRODUTO
  (nomeProduto, precoUnitario, idArea)
VALUES
  ('Veja', 2400, 2),
  ('Banana', 1000, 1),
  ('Perfume', 3000, 3);
  
INSERT INTO VENDA
  (dtVenda, matricula)
VALUES
  ('2021-07-26 14:10:20', 1),
  ('2021-05-12 17:23:10', 2),
  ('2021-02-13 20:55:14', 3);
  
INSERT INTO telefone
  (matricula, telefone)
VALUES
  (1, '61996927595'),
  (2, '61999866794'),
  (3, '61999844529');
  
INSERT INTO possui
  (idVenda, idProduto, quantidade)
VALUES
  (1, 1, 10),
  (2, 2, 1),
  (3, 3, 12);
	