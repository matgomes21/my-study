-- ------------------------------------------   << PROJETO Aula 1 Exercício 2  >>   ------------------------------------------
--
--                                                SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 26/07/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula1exer2
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ------------------------------------------------------------------------------------------------------------------------

DROP TABLE possui;
DROP TABLE telefone;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;
DROP TABLE PESSOA;