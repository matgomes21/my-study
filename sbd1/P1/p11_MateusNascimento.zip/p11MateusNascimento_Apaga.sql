-- ---------------------     << Prova 1 >>     ---------------------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 13/04/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: MateusNascimento
-- 
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- -----------------------------------------------------------------

USE MateusNascimento;

DROP TABLE contrata;
DROP TABLE telefone;
DROP TABLE TRABALHADOR;
DROP TABLE SUPERVISOR;
DROP TABLE AREA;
DROP TABLE EMPRESA;