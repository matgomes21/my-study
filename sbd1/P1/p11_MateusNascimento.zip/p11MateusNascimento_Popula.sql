-- ---------------------     << Prova 1 >>     ---------------------
--
--                    SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 13/04/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: MateusNascimento
-- 
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- -----------------------------------------------------------------

USE MateusNascimento;

INSERT INTO EMPRESA (razaoSocial, endereco, dtIntegracao)
VALUES
  ("EletronJun", "Quadra 44 Setor Leste Gama Brasilia DF", "2021-04-13"),
  ("Topografia Top Service", "CSB 9 Lote 4 Loja 1 Brasilia DF", "2021-03-10");

INSERT INTO AREA (nome)
VALUES
  ("Gerente de Marketing"),
  ("Assessor de Operações");

INSERT INTO SUPERVISOR (matriculaFuncional, cpf, nomeCompleto, dtNascimento, sexo, idEmpresa)
VALUES
  ("180106821", "01374926183", "Mateus Gomes do Nascimento", "2000-01-21", "M", 100),
  ("170106821", "72374926183", "Gabriela Dantas da Silva", "1999-02-13", "F", 101);
  
INSERT INTO TRABALHADOR (cpf, nomeCompleto, sexo, dtNascimento, matriculaFuncional, idArea)
VALUES
  ("44374926183", "Pablo Nogueira Figueiredo", "M", "1997-05-11", "180106821", 100),
  ("77374926183", "Ana Teresa Borges", "F", "2000-06-29", "170106821", 101);
  
INSERT INTO telefone(cpf, telefone)
  VALUES
	("44374926183", 996927595),
    ("77374926183", 999866784);

INSERT INTO contrata(idEmpresa, cpf)
  VALUES
	(100, "44374926183"),
    (101, "77374926183");