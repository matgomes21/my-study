-- ---------------------     << Prova 1 >>     ---------------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 13/04/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: MateusNascimento
-- 
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS MateusNascimento;

USE MateusNascimento;

CREATE TABLE EMPRESA (
    idEmpresa INT NOT NULL AUTO_INCREMENT,
    razaoSocial VARCHAR(100) NOT NULL,
    endereco VARCHAR(150) NOT NULL,
    dtIntegracao DATE NOT NULL,
    
    CONSTRAINT EMPRESA_PK PRIMARY KEY (idEmpresa)
)ENGINE=InnoDB AUTO_INCREMENT=100;

CREATE TABLE AREA (
    idArea INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL UNIQUE,
    
    CONSTRAINT AREA_PK PRIMARY KEY (idArea)
)ENGINE=InnoDB AUTO_INCREMENT=100;

CREATE TABLE SUPERVISOR (
    matriculaFuncional VARCHAR(10) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    idEmpresa INT NOT NULL,
    
    CONSTRAINT SUPERVISOR_PK PRIMARY KEY (matriculaFuncional),
    
    CONSTRAINT SUPERVISOR_UK UNIQUE(cpf),
    
    CONSTRAINT nomeia_EMPRESA_FK FOREIGN KEY(idEmpresa)
		REFERENCES EMPRESA(idEmpresa)
)ENGINE=InnoDB;

CREATE TABLE TRABALHADOR (
    cpf VARCHAR(11) NOT NULL,
    nomeCompleto VARCHAR(100) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    dtNascimento DATE NOT NULL,
    matriculaFuncional VARCHAR(10) NOT NULL,
    idArea INT NOT NULL,
    
    CONSTRAINT TRABALHADOR_PK PRIMARY KEY (cpf),
    
    CONSTRAINT supervisiona_SUPERVISOR_FK FOREIGN KEY(matriculaFuncional)
		REFERENCES SUPERVISOR(matriculaFuncional),
	CONSTRAINT possui_AREA_FK FOREIGN KEY(idArea)
		REFERENCES AREA(idArea)
)ENGINE=InnoDB;

CREATE TABLE telefone (
    cpf VARCHAR(11) NOT NULL,
    telefone INT NOT NULL,
    
    CONSTRAINT telefone_TRABALHADOR_FK FOREIGN KEY(cpf)
		REFERENCES TRABALHADOR(cpf),
    
    CONSTRAINT telefone_UK UNIQUE(cpf, telefone)
)ENGINE=InnoDB;

CREATE TABLE contrata (
    idEmpresa INT NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    
    CONSTRAINT contrata_UK UNIQUE (idEmpresa, cpf),
    
    CONSTRAINT contrata_EMPRESA_FK FOREIGN KEY(idEmpresa)
		REFERENCES EMPRESA(idEmpresa),
	CONSTRAINT contrata_TRABALHADOR_FK FOREIGN KEY(cpf)
		REFERENCES TRABALHADOR(cpf)
)ENGINE=InnoDB;