-- --------  << RECEITUÁRIO - aula4exer5Evolucao5 >>  ----------
--
--                    SCRIPT DE POPULACAO (DML)
--
-- Data Criacao ...........: 19/03/2021
-- Autor(es) ..............: Lucas Melo dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao5
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------
USE aula4exer5Evolucao5;
--

INSERT INTO MEDICO(nomeCompleto, crm, estado) VALUES
('Italo Silva Melo', 1030, 'RJ'),
('Marta Caixeta de Souza', 243322, 'SP'),
('Lucas Neves Pereira', 231113, 'DF'),
('Lucas Coutinho pereira', 3221140, 'CE');

INSERT INTO PACIENTE(nomeCompleto, dtNascimento, sexo, rua, numero, bairro, complemento, cidade, estado, cep) VALUES
('Carlos Figueireido Costa','1988-05-03', 'M',  'Rua Expedito José Sousa Farias 117', 714, 'Centro', null,'Sobral', 'CE', '72443301' ),
('Maria Ferreira de Souza','1970-03-10', 'F',  'Rua Sebastião Gomes Pereira', 798, 'Jardim Dayse', 'Em frente ao posto de gasolina','São Paulo', 'SP', '08528030'),
('Arthur Peixoto Dias', '1980-11-12', 'M',  'Beco São Jorge', 717,'Bonsucesso', 'em frente ao mercado Primor', 'Rio de Janeiro', 'RJ', '21042695'),
('Matheus Paes Lima', '1985-09-11', 'M',  'Quadra SRES Quadra 10 Bloco T1', 190, 'Cruzeiro Velho', null,'Cruzeiro Velho', 'DF', '70645201');	

INSERT INTO MEDICAMENTO(principioAtivo) VALUES
('DIPIRONA'),
('ROSUVASTINA'),
('HIDROQUINONA'),
('IBUPROFENO');

INSERT INTO ESPECIALIDADE(nomeEspecialidade) VALUES
 ('CARDIOLOGISTA'),
 ('DERMATOLOGISTA'),
 ('INFECTOLOGISTA'),
 ('NEUROLOGISTA');
 
INSERT INTO CONSULTA( dataConsulta, horaConsulta, crm, estado, idPaciente) VALUES
('2017-09-16', '13:10:15', 1030, 'RJ', 3),
('2019-10-11', '14:09:12', 231113, 'DF', 2),
('2020-09-16', '19:10:10', 243322, 'SP', 1),
('2016-02-03', '16:10:55', 3221140, 'CE', 4);

INSERT INTO RECEITA(recomendacao, dataEmissao, posologia, idConsulta) VALUES
('ficar de repouso durante 2 semanas','2017-09-16', 'tomar dipirona 2 vezes ao dia durante 2 semanas ', 1),
('fazer atividade física 3x por semana','2019-10-11', 'tomar rosuvastatina 1 vez por dia durante 1 mês', 2),
(null,'2020-09-16', 'usar todos os dias Hidroquinona por 2 meses', 3),
(null, '2016-02-03', 'tomar ibuprofeno por 2 semanas de 8 em 8 horas', 4);
 
 INSERT INTO possui(crm, estado, idEspecialidade) VALUES
 (1030, 'RJ', 1),
 (243322, 'SP', 2),
 (231113, 'DF', 3),
 (3221140, 'CE', 4);
 

INSERT INTO telefone(idPaciente, telefone) VALUES
(1, '6198321-4401'),
(2, '6193211-3874'),
(3, '6199032-2880'),
(4, '6199032-2880');


INSERT INTO contem(idReceita, idMedicamento)VALUES
  (1,1),
  (2,2),
  (3,3),
  (4,4);
