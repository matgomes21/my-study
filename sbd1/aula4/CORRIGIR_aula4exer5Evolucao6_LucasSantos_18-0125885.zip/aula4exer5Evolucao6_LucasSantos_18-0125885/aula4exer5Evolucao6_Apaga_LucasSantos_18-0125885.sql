-- --------  << RECEITUÁRIO - aula4exer5Evolucao6  >>  ----------
--
--                    SCRIPT DE APAGAR (DDL)
--
-- Data Criacao ...........: 29/03/2021
-- Autor(es) ..............: Lucas Melo dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6
--
-- Ultimas Alteracoes
--
-- PROJETO => 01 Base de Dados
--         => 9 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer5Evolucao6;

DROP TABLE contem;
DROP TABLE MEDICAMENTO;
DROP TABLE RECEITA;
DROP TABLE CONSULTA;
DROP TABLE telefone;
DROP TABLE PACIENTE;
DROP TABLE possui;
DROP TABLE MEDICO;
DROP TABLE ESPECIALIDADE;

