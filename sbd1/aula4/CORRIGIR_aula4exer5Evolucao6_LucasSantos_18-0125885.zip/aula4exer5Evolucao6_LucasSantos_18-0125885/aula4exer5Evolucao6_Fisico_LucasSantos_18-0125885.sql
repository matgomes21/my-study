-- --------  << PROJETO Aula 4 Exercicio 5 Evolucao 6 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 29/03/2021
-- Autor(es) ..............: Lucas Melo dos Santos
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao6
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
    IF NOT EXISTS aula4exer5Evolucao6;

USE aula4exer5Evolucao6;


-- TABELAS
CREATE TABLE MEDICO (
	nomeCompleto VARCHAR(80) NOT NULL,
    crm VARCHAR(10) NOT NULL,
    estado CHAR(2) NOT NULL,
    CONSTRAINT MEDICO_PK PRIMARY KEY (crm, estado)
) ENGINE = InnoDB;


CREATE TABLE ESPECIALIDADE (
	nomeEspecialidade VARCHAR(50) NOT NULL,
    idEspecialidade INT NOT NULL AUTO_INCREMENT,
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY (idEspecialidade)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


CREATE TABLE PACIENTE (
    idPaciente INT AUTO_INCREMENT NOT NULL,
    nomeCompleto VARCHAR(80) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('F','M') NOT NULL,
    rua VARCHAR(40) NOT NULL,
    numero INT,
    bairro VARCHAR(50) NOT NULL,
    complemento VARCHAR(100),
    cidade VARCHAR(30) NOT NULL,
    estado CHAR(2) NOT NULL,
    cep VARCHAR(8) NOT NULL,
    CONSTRAINT PACIENTE_PK PRIMARY KEY (idPaciente)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


CREATE TABLE telefone (
    idPaciente INT NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE(idPaciente)
) ENGINE = InnoDB;


CREATE TABLE CONSULTA (
    idConsulta INT NOT NULL AUTO_INCREMENT,
    dataConsulta DATE NOT NULL,
    horaConsulta TIME NOT NULL,
    crm VARCHAR(10) NOT NULL,
    estado CHAR(2) NOT NULL,
    idPaciente INT NOT NULL,
    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta),
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (crm, estado)
	REFERENCES MEDICO(crm, estado),
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (idPaciente)
	REFERENCES PACIENTE(idPaciente)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


CREATE TABLE RECEITA (
    idReceita INT NOT NULL AUTO_INCREMENT,
    dataEmissao DATE NOT NULL,
    posologia VARCHAR(255) NOT NULL,
    idConsulta INT NOT NULL,
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    CONSTRAINT RECEITA_CONSULTA_FK FOREIGN KEY (idConsulta)
     REFERENCES CONSULTA(idConsulta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


CREATE TABLE MEDICAMENTO (
    idMedicamento INT NOT NULL AUTO_INCREMENT,
    principioAtivo VARCHAR(30) NOT NULL,
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (idMedicamento)
) ENGINE = InnoDB AUTO_INCREMENT = 1;


CREATE TABLE possui (
    crm VARCHAR(10),
    estado CHAR(2),
    idEspecialidade INT,
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY (crm, estado)
	REFERENCES MEDICO(crm, estado),
	CONSTRAINT possui_ESPECIALIDADE_FK FOREIGN KEY (idEspecialidade)
	REFERENCES ESPECIALIDADE(idEspecialidade)
) ENGINE = InnoDB;


CREATE TABLE contem (
    idReceita INT NOT NULL,
    idMedicamento INT NOT NULL,
    CONSTRAINT contem_RECEITA_FK FOREIGN KEY (idReceita)
     REFERENCES RECEITA(idReceita),
    CONSTRAINT contem_MEDICAMENTO_FK FOREIGN KEY (idMedicamento)
     REFERENCES MEDICAMENTO(idMedicamento)
) ENGINE = InnoDB;
