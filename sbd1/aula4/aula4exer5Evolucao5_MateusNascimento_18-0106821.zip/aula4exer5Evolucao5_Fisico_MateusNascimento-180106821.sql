- --------  << Sistema da Clínica >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 22/03/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao5
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula4exer5Evolucao5;
USE aula4exer5Evolucao5;

CREATE TABLE IF NOT EXISTS MEDICO (
    numeroCrm int NOT NULL,
    uf varchar(2) NOT NULL,
    nome varchar(100) NOT NULL,
    PRIMARY KEY (numeroCrm, uf)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS PACIENTE (
    idPaciente int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome varchar(100) NOT NULL,
    dtNascimento varchar(10) NOT NULL,
    idade int NOT NULL,
    sexo varchar(10) NOT NULL,
    cep int NOT NULL,
    bairro varchar(100) NOT NULL,
    rua varchar(100) NOT NULL,
    numero int NOT NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS CONSULTA (
    idConsulta int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    dtConsulta varchar(10) NOT NULL,
    hrConsulta varchar(5) NOT NULL,
    numeroCrm int NOT NULL,
    uf varchar(2) NOT NULL,
    idPaciente int NOT NULL,
    
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (numeroCrm, uf)
        REFERENCES MEDICO (numeroCrm, uf),
    CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (idPaciente)
        REFERENCES PACIENTE (idPaciente)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS PRESCRICAO (
    idPrescricao int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    dtEmissao varchar(10) NOT NULL,
    instrucao varchar(100) NOT NULL,
    hrEmissao varchar(5) NOT NULL,
    idConsulta int NOT NULL,
    
    CONSTRAINT PRESCRICAO_CONSULTA_FK FOREIGN KEY (idConsulta)
        REFERENCES CONSULTA (idConsulta)
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS ESPECIALIZACAO (
    idEspecializacao int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nomeEspecializacao varchar(100) NOT NULL
) ENGINE = InnoDB AUTO_INCREMENT = 1;

CREATE TABLE IF NOT EXISTS telefone (
    idPaciente INT NOT NULL,
    telefone int NOT NULL,
    
    CONSTRAINT telefone_PACIENTE_FK FOREIGN KEY (idPaciente)
        REFERENCES PACIENTE (idPaciente)
);

CREATE TABLE IF NOT EXISTS medicamento (
    idPrescricao INT NOT NULL,
    medicamento varchar(100) NOT NULL,
    
    CONSTRAINT medicamento_PRESCRICAO_FK FOREIGN KEY (idPrescricao)
        REFERENCES PRESCRICAO (idPrescricao)
);

CREATE TABLE IF NOT EXISTS possui (
    numeroCrm int NOT NULL,
    uf varchar(2) NOT NULL,
    idEspecializacao int NOT NULL,
    
    CONSTRAINT possui_MEDICO_FK FOREIGN KEY (numeroCrm, uf)
        REFERENCES MEDICO (numeroCrm, uf),
    CONSTRAINT possui_ESPECIALIZACAO_FK FOREIGN KEY (idEspecializacao)
        REFERENCES ESPECIALIZACAO (idEspecializacao)
);