- --------  << Sistema da Clínica >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 22/03/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao5
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer5Evolucao5;

DROP TABLE IF EXISTS possui;
DROP TABLE IF EXISTS medicamento;
DROP TABLE IF EXISTS telefone;
DROP TABLE IF EXISTS ESPECIALIZACAO;
DROP TABLE IF EXISTS PRESCRICAO;
DROP TABLE IF EXISTS CONSULTA;
DROP TABLE IF EXISTS PACIENTE;
DROP TABLE IF EXISTS MEDICO;