- --------  << Sistema da Clínica >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 22/03/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer5Evolucao5
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- ---------------------------------------------------------

USE aula4exer5Evolucao5;

INSERT INTO MEDICO
	( numeroCrm, uf, nome )
    VALUES
    ( 12233, 'DF', 'Mateus Gomes do Nascimento' ),
    ( 12453, 'MG', 'Carlos Eduardo Nogueira' ),
    ( 12673, 'RJ', 'Felipe Gonçalves Azevedo' ),
    ( 12893, 'SP', 'Silvio Santos da Silva' );

INSERT INTO PACIENTE
    ( nome, dtNascimento, idade, sexo, cep, bairro, rua, numero )
VALUES
    ( 'Cleide de Almeida Gomes do Nascimento', '2000-01-21', 21, 'Feminino', 72015595, 'Taguatinga', 'CSB 9', 4 ),
    ( 'João Lucas Pereira', '1998-02-03', 23, 'Masculino', 72015777, 'Águas Claras', 'Av. Araucárias', 12 ),
    ( 'Lucas Lima Fernandes', '1999-03-12', 22, 'Masculino', 71015335, 'Samambaia', 'QNL 3', 2 ),
    ( 'Manuel Gonçalves Lima', '1971-02-20', 40, 'Masculino', 73335595, 'Taguatinga', 'CSB 7', 1 );

INSERT INTO CONSULTA
    ( dtConsulta, hrConsulta, numeroCrm, uf, idPaciente )
VALUES
    ( '22/03/2021', '14:00', 12233, 'DF', 1 ),
    ( '21/03/2021', '17:21', 12233, 'DF', 2 ),
    ( '22/03/2021', '10:03', 12233, 'DF', 3 ),
    ( '20/03/2021', '18:20', 12233, 'DF', 4 );
    
INSERT INTO PRESCRICAO
	( dtEmissao, instrucao, hrEmissao, idConsulta )
VALUES
	( '22/03/2021', '3 doses por dia', '14:12', 1 ),
    ( '21/03/2021', 'tomar antes de dormir', '17:30', 2 ),
    ( '22/03/2021', '4 doses por dia', '10:12', 3 ),
    ( '20/03/2021', '40mg por dia', '18:25', 4 );
    
INSERT INTO ESPECIALIZACAO
	( nomeEspecializacao )
VALUES 
	( 'Cardiologista'),
    ( 'Neurologista'),
    ( 'Clínico Geral'),
    ( 'Gastrologista');
    
INSERT INTO telefone
	( idPaciente, telefone )
VALUES
	( 1, 996927595 ),
    ( 2, 998727591 ),
    ( 3, 981927332 ),
    ( 4, 999866784 );
    
INSERT INTO medicamento
	( idPrescricao, medicamento )
VALUES
	( 1, 'Paracetamol'),
    ( 2, 'Neosoro'),
    ( 3, 'Novalgina'),
    ( 4, 'Torcilax');
    
INSERT INTO possui
	( numeroCrm, uf, idEspecializacao )
VALUES
	( 12233, 'DF', 1),
    ( 12233, 'DF', 2),
    ( 12453, 'MG', 3),
    ( 12893, 'SP', 4);