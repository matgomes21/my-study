-- --------  << bdClinica >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 15/03/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: bdClinica
--
-- Ultimas Alteracoes
--   15/03/2021 => Criacao do banco de dados e das tabelas
--
-- PROJETO => 01 Base de Dados
--         => 11 Tabelas
--
-- ---------------------------------------------------------
CREATE DATABASE bdClinica;
USE bdClinica;

CREATE TABLE MEDICO (
    numeroCrm int NOT NULL,
    uf char(2) NOT NULL,
    nome varchar(100) NOT NULL,
    especializacao varchar(100) NOT NULL,
    PRIMARY KEY (numeroCrm, uf)
);

CREATE TABLE CONSULTA (
    idConsulta int NOT NULL PRIMARY KEY,
    dataConsulta varchar(10) NOT NULL,
    horaConsulta varchar(5) NOT NULL,
    numeroCrm int NOT NULL,
    uf char(2) NOT NULL,
    idPaciente int NOT NULL
);

CREATE TABLE PACIENTE (
    idPaciente int NOT NULL PRIMARY KEY,
    nome varchar(100) NOT NULL,
    dtNascimento varchar(10) NOT NULL,
    idade int NOT NULL,
    sexo varchar(9) NOT NULL,
    cep varchar(8) NOT NULL,
    bairro varchar(100) NOT NULL,
    rua varchar(100) NOT NULL,
    numero int NOT NULL,
    telefone int NOT NULL
);

CREATE TABLE PRESCRICAO (
    idPrescricao int NOT NULL PRIMARY KEY,
    dtEmissao varchar(10) NOT NULL,
    instrucao varchar(200) NOT NULL,
    hrEmissao varchar(5),
    idConsulta int NOT NULL,
    medicamento int NOT NULL
);

CREATE TABLE telefone (
    idPaciente int NOT NULL PRIMARY KEY,
    telefone int NOT NULL
);

CREATE TABLE medicamento (
    idPrescricao int NOT NULL PRIMARY KEY,
    medicamento varchar(100) NOT NULL
);
 
ALTER TABLE CONSULTA ADD CONSTRAINT FK_CONSULTA_2
    FOREIGN KEY (numeroCrm, uf)
    REFERENCES MEDICO (numeroCrm, uf);
 
ALTER TABLE CONSULTA ADD CONSTRAINT FK_CONSULTA_3
    FOREIGN KEY (idPaciente)
    REFERENCES PACIENTE (idPaciente);
 
ALTER TABLE PACIENTE ADD CONSTRAINT FK_PACIENTE_2
    FOREIGN KEY (telefone)
    REFERENCES telefone (idPaciente)
    ON DELETE NO ACTION;
 
ALTER TABLE PRESCRICAO ADD CONSTRAINT FK_PRESCRICAO_MEDICAMENTO
    FOREIGN KEY (medicamento)
    REFERENCES medicamento (idPrescricao)
    ON DELETE NO ACTION;
 
ALTER TABLE PRESCRICAO ADD CONSTRAINT FK_PRESCRICAO_3
    FOREIGN KEY (idConsulta)
    REFERENCES CONSULTA (idConsulta)
    ON DELETE CASCADE;