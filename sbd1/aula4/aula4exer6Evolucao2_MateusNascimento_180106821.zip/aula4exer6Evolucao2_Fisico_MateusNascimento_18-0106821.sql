-- --------  << Sistema Detran >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 17/03/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: bdDetran
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE dbDetran;

USE dbDetran;

CREATE TABLE VEICULO (
    placa varchar(7) NOT NULL PRIMARY KEY,
    chassi varchar(100) NOT NULL,
    ano int NOT NULL,
    cor varchar(100) NOT NULL,
    cpf varchar(11) NOT NULL,
    idCategoria int NOT NULL,
    idModelo int NOT NULL
);

CREATE TABLE MODELO (
    idModelo int NOT NULL PRIMARY KEY,
    nomeModelo varchar(100) NOT NULL
);

CREATE TABLE CATEGORIA (
    idCategoria int NOT NULL PRIMARY KEY,
    nomeCategoria varchar(100) NOT NULL
);

CREATE TABLE PROPRIETARIO (
    cpf varchar(11) NOT NULL PRIMARY KEY,
    nomeProprietario varchar(100) NOT NULL,
    sexo varchar(9) NOT NULL,
    dtNascimento varchar(10) NOT NULL,
    idade int NOT NULL,
    bairro varchar(100) NOT NULL,
    cidade varchar(100) NOT NULL,
    uf char(2) NOT NULL,
    idTelefone int NOT NULL
);

CREATE TABLE INFRACAO (
    idInfracao int NOT NULL PRIMARY KEY,
    dtInfracao varchar(10) NOT NULL,
    hrInfracao varchar(5) NOT NULL,
    velocidadeVeiculo int NOT NULL,
    placa varchar(7) NOT NULL,
    matriculaFuncional int NOT NULL,
    idTipo int NOT NULL,
    idLocal int NOT NULL
);

CREATE TABLE AGENTE (
    matriculaFuncional int NOT NULL PRIMARY KEY,
    nomeAgente varchar(100) NOT NULL,
    dtContratacao varchar(10) NOT NULL,
    tempoServico varchar(5) NOT NULL
);

CREATE TABLE TIPO (
    idTipo int NOT NULL PRIMARY KEY,
    nomeTipo varchar(100) NOT NULL,
    valor int NOT NULL
);

CREATE TABLE LOCAL (
    idLocal int NOT NULL PRIMARY KEY,
    velocidadeMaxima int NOT NULL,
    latitude varchar(100) NOT NULL,
    longitude varchar(100) NOT NULL
);

CREATE TABLE telefone (
    idTelefone INT NOT NULL PRIMARY KEY,
    telefone INT NOT NULL
);