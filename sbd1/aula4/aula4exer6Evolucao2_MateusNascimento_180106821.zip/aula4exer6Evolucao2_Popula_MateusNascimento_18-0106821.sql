USE dbDetran;

INSERT INTO VEICULO (
	placa ,
    chassi,
    ano,
    cor,
    cpf,
    idCategoria,
    idModelo
) VALUES (
	'FVV7242',
    '2ABXC44R77Y123244',
    2008,
    'Vermelho',
    '01374926672',
    1,
    1
);

INSERT INTO VEICULO (
	placa ,
    chassi,
    ano,
    cor,
    cpf,
    idCategoria,
    idModelo
) VALUES (
	'ABC7242',
    '3YZXC44R77Y123244',
    2009,
    'Azul',
    '71374926672',
    1,
    2
);

INSERT INTO VEICULO (
	placa ,
    chassi,
    ano,
    cor,
    cpf,
    idCategoria,
    idModelo
) VALUES (
	'JFX7242',
    '3DLLXC44R77Y123244',
    19999,
    'cINZA',
    '70174926672',
    1,
    3
);

INSERT INTO MODELO (
	idModelo,
    nomeModelo
) VALUES (
	1,
    'Uno'
);

INSERT INTO MODELO (
	idModelo,
    nomeModelo
) VALUES (
	2,
    'Eco Sport'
);

INSERT INTO MODELO (
	idModelo,
    nomeModelo
) VALUES (
	3,
    'Parati'
);

INSERT INTO CATEGORIA(
	idCategoria,
    nomeCategoria
) VALUES (
	1,
    'Carro de passeio'
);

INSERT INTO CATEGORIA(
	idCategoria,
    nomeCategoria
) VALUES (
	2,
    'Motocicleta'
);

INSERT INTO CATEGORIA(
	idCategoria,
    nomeCategoria
) VALUES (
	3,
    'Camioneta'
);

INSERT INTO PROPRIETARIO (
	cpf,
    nomeProprietario,
    sexo,
    dtNascimento,
    idade,
    bairro,
    cidade,
    uf,
    idTelefone
) VALUES (
	'01374926672',
    'Vanderlei Silva',
    'Masculino',
    '21/01/1977',
    44,
    'Taguatinga',
    'Brasília',
    'DF',
    1
);

INSERT INTO PROPRIETARIO (
	cpf,
    nomeProprietario,
    sexo,
    dtNascimento,
    idade,
    bairro,
    cidade,
    uf,
    idTelefone
) VALUES (
	'71374926672',
    'Ricardo Andrade',
    'Masculino',
    '23/03/1976',
    45,
    'Samambaia',
    'Brasília',
    'DF',
    2
);

INSERT INTO PROPRIETARIO (
	cpf,
    nomeProprietario,
    sexo,
    dtNascimento,
    idade,
    bairro,
    cidade,
    uf,
    idTelefone
) VALUES (
	'70174926672',
    'Cláudia Almeida',
    'Feminino',
    '22/02/2000',
    21,
    'Ceilândia',
    'Brasília',
    'DF',
    3
);

INSERT INTO INFRACAO (
	idInfracao,
    dtInfracao,
    hrInfracao,
    velocidadeVeiculo,
    placa,
    matriculaFuncional,
    idTipo,
    idLocal
) VALUES(
	1,
    '17/03/2021',
    '14:05',
    120,
    'FVV7242',
    '180106821',
    1,
    1
);

INSERT INTO INFRACAO (
	idInfracao,
    dtInfracao,
    hrInfracao,
    velocidadeVeiculo,
    placa,
    matriculaFuncional,
    idTipo,
    idLocal
) VALUES(
	2,
    '17/03/2021',
    '17:05',
    123,
    'FVV7242',
    '180106821',
    1,
    2
);

INSERT INTO INFRACAO (
	idInfracao,
    dtInfracao,
    hrInfracao,
    velocidadeVeiculo,
    placa,
    matriculaFuncional,
    idTipo,
    idLocal
) VALUES(
	3,
    '17/03/2021',
    '18:30',
    300,
    'FVV7242',
    '180106821',
    1,
    1
);

INSERT INTO AGENTE(
	matriculaFuncional,
    nomeAgente,
    dtContratacao,
    tempoServico
) VALUES (
	'180106821',
    'Gilberto Gil',
    '01/01/2020',
    '8h'
);

INSERT INTO AGENTE(
	matriculaFuncional,
    nomeAgente,
    dtContratacao,
    tempoServico
) VALUES (
	'190106821',
    'Carla Diaz',
    '01/01/2019',
    '4h'
);

INSERT INTO AGENTE(
	matriculaFuncional,
    nomeAgente,
    dtContratacao,
    tempoServico
) VALUES (
	'200106821',
    'Felipe Gonçalves',
    '22/02/2021',
    '8h'
);

INSERT INTO TIPO (
	idTipo,
    nomeTipo,
    valor
) VALUES (
	1,
    'Excesso de Velocidade',
    200
);

INSERT INTO TIPO (
	idTipo,
    nomeTipo,
    valor
) VALUES (
	2,
    'Dirigir sem habilitação',
    1000
);

INSERT INTO TIPO (
	idTipo,
    nomeTipo,
    valor
) VALUES (
	3,
    'Não parar na parada obrigatória',
    150
);

INSERT INTO LOCAL (
	idLocal,
    velocidadeMaxima,
    latitude,
    longitude
) VALUES (
	1,
    80,
    '100004y',
    '100004x'
);

INSERT INTO LOCAL (
	idLocal,
    velocidadeMaxima,
    latitude,
    longitude
) VALUES (
	2,
    60,
    '100334y',
    '100774x'
);

INSERT INTO LOCAL (
	idLocal,
    velocidadeMaxima,
    latitude,
    longitude
) VALUES (
	3,
    110,
    '230066y',
    '230077x'
);

INSERT INTO telefone (
	idTelefone,
    telefone
) VALUES (
	1,
    996978855
);

INSERT INTO telefone (
	idTelefone,
    telefone
) VALUES (
	2,
    981978855
);

INSERT INTO telefone (
	idTelefone,
    telefone
) VALUES (
	3,
    981878325
);