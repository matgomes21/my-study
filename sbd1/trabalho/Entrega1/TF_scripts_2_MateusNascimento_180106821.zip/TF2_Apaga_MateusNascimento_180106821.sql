-- --------  << FARMÁCIA DO POSTO DE SAÚDE >>  ----------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 03/05/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: FarmaciaDoPostoDeSaudeMateusNascimento
--
-- PROJETO => 01 Base de Dados
--         => 18 Tabelas
--
-- ---------------------------------------------------------

USE FarmaciaDoPostoDeSaudeMateusNascimento;

DROP TABLE contem;
DROP TABLE abastece;
DROP TABLE possui;
DROP TABLE atende;
DROP TABLE tem;
DROP TABLE atua;
DROP TABLE trabalha;
DROP TABLE FARMACIA;
DROP TABLE FARMACEUTICO;
DROP TABLE ENFERMEIRA;
DROP TABLE FORNECEDOR;
DROP TABLE SUPRIMENTO;
DROP TABLE RECEITA;
DROP TABLE ATENDIMENTO;
DROP TABLE MEDICO;
DROP TABLE PACIENTE;
DROP TABLE MEDICAMENTO;
DROP TABLE PORTARIA;