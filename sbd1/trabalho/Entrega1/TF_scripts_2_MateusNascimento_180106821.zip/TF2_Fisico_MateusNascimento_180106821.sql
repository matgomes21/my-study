-- --------  << FARMÁCIA DO POSTO DE SAÚDE >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 03/05/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: FarmaciaDoPostoDeSaudeMateusNascimento
--
-- PROJETO => 01 Base de Dados
--         => 18 Tabelas
--
-- ---------------------------------------------------------

CREATE DATABASE
    IF NOT EXISTS FarmaciaDoPostoDeSaudeMateusNascimento;
    
USE FarmaciaDoPostoDeSaudeMateusNascimento;

CREATE TABLE PORTARIA (
    idPortaria INT NOT NULL PRIMARY KEY,
    tipoMedicamento VARCHAR(100) NOT NULL
)ENGINE=InnoDB;

CREATE TABLE MEDICAMENTO (
    idMedicamento INT NOT NULL AUTO_INCREMENT,
    nomeMedicamento VARCHAR(100) NOT NULL,
    idPortaria INT NOT NULL,
    
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (idMedicamento),
    
    CONSTRAINT MEDICAMENTO_PORTARIA_FK FOREIGN KEY(idPortaria)
		REFERENCES PORTARIA(idPortaria)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE PACIENTE (
    cpfPaciente VARCHAR(11) NOT NULL,
    cartaoSus INT NOT NULL,
    identidade VARCHAR(20) NOT NULL,
    nomePaciente VARCHAR(100) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    
    CONSTRAINT PACIENTE_PK PRIMARY KEY (cpfPaciente),
    
   CONSTRAINT PACIENTE_UK UNIQUE (cartaoSus, identidade)
)ENGINE=InnoDB;

CREATE TABLE MEDICO (
    identificador INT NOT NULL,
    uf VARCHAR(2) NOT NULL,
    nomeMedico VARCHAR(100) NOT NULL,
    
    CONSTRAINT MEDICO_PK PRIMARY KEY (identificador, uf)
)ENGINE=InnoDB;

CREATE TABLE ATENDIMENTO (
    idAtendimento INT NOT NULL AUTO_INCREMENT,
    dtAtendimento DATE NOT NULL,
    hrAtendimento TIME NOT NULL,
    cpfPaciente VARCHAR(11) NOT NULL,
    identificador INT NOT NULL,
    uf VARCHAR(2) NOT NULL,
    
    CONSTRAINT ATENDIMENTO_PK PRIMARY KEY (idAtendimento),
    
    CONSTRAINT ATENDIMENTO_PACIENTE_FK FOREIGN KEY(cpfPaciente)
		REFERENCES PACIENTE(cpfPaciente),
	 CONSTRAINT ATENDIMENTO_MEDICO_FK FOREIGN KEY(identificador, uf)
		REFERENCES MEDICO(identificador, uf)
        
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE RECEITA (
    idReceita INT NOT NULL AUTO_INCREMENT,
    dtEmissao DATE NOT NULL,
    dosagem VARCHAR(100) NOT NULL,
    orientacao VARCHAR(100) NOT NULL,
    idAtendimento INT NOT NULL,
    
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    
     CONSTRAINT RECEITA_ATENDIMENTO_FK FOREIGN KEY(idAtendimento)
		REFERENCES ATENDIMENTO(idAtendimento)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE SUPRIMENTO (
    idSuprimento INT NOT NULL AUTO_INCREMENT,
    nomeSuprimento VARCHAR(100) NOT NULL,
    
    CONSTRAINT SUPRIMENTO_PK PRIMARY KEY (idSuprimento)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE FORNECEDOR (
    idFornecedor INT NOT NULL AUTO_INCREMENT,
    nomeFornecedor VARCHAR(100) NOT NULL,
    
    CONSTRAINT FORNECEDOR_PK PRIMARY KEY (idFornecedor)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE ENFERMEIRA (
    idEnfermeira INT NOT NULL AUTO_INCREMENT,
    nomeEnfermeira VARCHAR(100) NOT NULL,
    
    CONSTRAINT ENFERMEIRA_PK PRIMARY KEY (idEnfermeira)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE FARMACEUTICO (
    crfFarmaceutico INT NOT NULL,
    nomeFarmaceutico VARCHAR(100) NOT NULL,
    
    CONSTRAINT FARMACEUTICO_PK PRIMARY KEY (crfFarmaceutico)
)ENGINE=InnoDB;

CREATE TABLE FARMACIA (
    idFarmacia INT NOT NULL AUTO_INCREMENT,
    nomeFarmacia VARCHAR(100) NOT NULL,
    cep VARCHAR(8) NOT NULL,
    uf VARCHAR(2) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    
    CONSTRAINT FARMACIA_PK PRIMARY KEY (idFarmacia)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE trabalha (
    idFarmacia INT NOT NULL,
    crfFarmaceutico INT NOT NULL,
    
     CONSTRAINT trabalha_FARMACIA_FK FOREIGN KEY(idFarmacia)
		REFERENCES FARMACIA(idFarmacia),
	 CONSTRAINT trabalha_FARMACEUTICO_FK FOREIGN KEY(crfFarmaceutico)
		REFERENCES FARMACEUTICO(crfFarmaceutico)
)ENGINE=InnoDB;

CREATE TABLE atua (
    idEnfermeira INT NOT NULL,
    idFarmacia INT NOT NULL,
    
     CONSTRAINT atua_ENFERMEIRA_FK FOREIGN KEY(idEnfermeira)
		REFERENCES ENFERMEIRA(idEnfermeira),
	 CONSTRAINT atua_FARMACIA_FK FOREIGN KEY(idFarmacia)
		REFERENCES FARMACIA(idFarmacia)
)ENGINE=InnoDB;

CREATE TABLE tem (
    idMedicamento INT NOT NULL,
    idReceita INT NOT NULL,
    
     CONSTRAINT tem_MEDICAMENTO_FK FOREIGN KEY(idMedicamento)
		REFERENCES MEDICAMENTO(idMedicamento),
	 CONSTRAINT tem_RECEITA_FK FOREIGN KEY(idReceita)
		REFERENCES RECEITA(idReceita)
)ENGINE=InnoDB;

CREATE TABLE atende (
    crfFarmaceutico INT NOT NULL,
    cpfPaciente VARCHAR(11) NOT NULL,
    
     CONSTRAINT atende_FARMACEUTICO_FK FOREIGN KEY(crfFarmaceutico)
		REFERENCES FARMACEUTICO(crfFarmaceutico),
	 CONSTRAINT atende_PACIENTE_FK FOREIGN KEY(cpfPaciente)
		REFERENCES PACIENTE(cpfPaciente)
)ENGINE=InnoDB;

CREATE TABLE possui (
    idFarmacia INT NOT NULL,
    idSuprimento INT NOT NULL,
    
    CONSTRAINT possui_FARMACIA_FK FOREIGN KEY(idFarmacia)
		REFERENCES FARMACIA(idFarmacia),
	 CONSTRAINT possui_SUPRIMENTO_FK FOREIGN KEY(idSuprimento)
		REFERENCES SUPRIMENTO(idSuprimento)
)ENGINE=InnoDB;

CREATE TABLE abastece (
    idFarmacia INT NOT NULL,
    idFornecedor INT NOT NULL,
    
    CONSTRAINT abastece_FARMACIA_FK FOREIGN KEY(idFarmacia)
		REFERENCES FARMACIA(idFarmacia),
	 CONSTRAINT abastece_FORNECEDOR_FK FOREIGN KEY(idFornecedor)
		REFERENCES FORNECEDOR(idFornecedor)
)ENGINE=InnoDB;

CREATE TABLE contem (
    idMedicamento INT NOT NULL,
    idFarmacia INT NOT NULL,
    
    CONSTRAINT contem_MEDICAMENTO_FK FOREIGN KEY(idMedicamento)
		REFERENCES MEDICAMENTO(idMedicamento),
	 CONSTRAINT contem_FARMACIA_FK FOREIGN KEY(idFarmacia)
		REFERENCES FARMACIA(idFarmacia)
)ENGINE=InnoDB;