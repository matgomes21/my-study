-- --------  << FARMÁCIA DO POSTO DE SAÚDE >>  ----------
--
--                    SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 03/05/2021
-- Autor(es) ..............: Mateus Gomes do Nascimento
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: FarmaciaDoPostoDeSaudeMateusNascimento
--
-- PROJETO => 01 Base de Dados
--         => 18 Tabelas
--
-- ---------------------------------------------------------

USE FarmaciaDoPostoDeSaudeMateusNascimento;

INSERT INTO PORTARIA (idPortaria, tipoMedicamento)
VALUES
  (202,"Analgésico"),
  (205,"Anestesiante"),
  (210,"Antidepressivo");

INSERT INTO MEDICAMENTO (nomeMedicamento, idPortaria)
VALUES
  ("Morfina", 202),
  ("Exitalopran", 210),
  ("Venlafaxina", 210);
  
INSERT INTO PACIENTE (cpfPaciente, cartaoSus, identidade, nomePaciente, dtNascimento, sexo)
VALUES
  ("01374926183", 77201, "3773041", "Mateus Gomes do Nascimento", "2000-01-21", 'M'),
  ("17274926183", 71201, "4883041", "Ana Teresa Borges Costa", "2000-06-29", 'F'),
  ("76374926112", 76202, "3443041", "Airton Brito da Costa", "1968-10-25", 'M');

INSERT INTO MEDICO (identificador, uf, nomeMedico)
VALUES
  (5502, "DF", "Carlos Alberto Nogueira"),
  (5401, "RJ", "Jessica da Silva Amaral"),
  (5312, "SP", "Katia Silva Costa");

INSERT INTO ATENDIMENTO (dtAtendimento, hrAtendimento, cpfPaciente, identificador, uf)
VALUES
  ("2021-05-01", "15:14:07", "01374926183", 5502, "DF"),
  ("2021-04-13", "10:30:02", "17274926183", 5401, "RJ"),
  ("2021-02-20", "14:24:05", "76374926112", 5312, "SP");

INSERT INTO RECEITA (dtEmissao, dosagem, orientacao, idAtendimento)
VALUES
  ("2021-05-01", "30mg", "tomar duas vezes ao dia", 1),
  ("2021-04-13", "50mg", "tomar antes de dormir", 2),
  ("2021-02-20", "60mg", "tomar a cada duas horas", 3);

INSERT INTO SUPRIMENTO (nomeSuprimento)
VALUES
  ("Gaze"),
  ("Álcool"),
  ("Bandagem");

INSERT INTO FORNECEDOR (nomeFornecedor)
VALUES
  ("Fernando Henrique Cardoso"),
  ("Giovana Fernandes Nogueira"),
  ("Felipe Costa e Silva");
  
INSERT INTO ENFERMEIRA (nomeEnfermeira)
VALUES
  ("Maurílio Mendes Nascimento"),
  ("Luciene Brito Borges"),
  ("Alanis Cirilo Lima");
  
INSERT INTO FARMACEUTICO (crfFarmaceutico, nomeFarmaceutico)
VALUES
  (5512, "Joaquim Costa Fernandes"),
  (5560, "Tiago Mesquita Andrade"),
  (5244, "Jéssica Amorim");

INSERT INTO FARMACIA (nomeFarmacia, cep, uf, logradouro)
VALUES
  ("Mais Saúde", "72015595", "DF", "CSB 9 Lt 4 Loja 1"),
  ("Paracatu", "72015777", "SP", "Bairro Liberdade Loja 4"),
  ("Drogaria Osasco", "72015656", "RJ", "Osasco Rua 3 Loja 5");

INSERT INTO trabalha (idFarmacia, crfFarmaceutico)
VALUES
  (1, 5512),
  (2, 5560),
  (3, 5244);

INSERT INTO atua (idEnfermeira, idFarmacia)
VALUES
  (1, 1),
  (2, 2),
  (3, 3);
  
INSERT INTO tem (idMedicamento, idReceita)
VALUES
  (1, 1),
  (2, 2),
  (3, 3);

INSERT INTO atende (crfFarmaceutico, cpfPaciente)
VALUES
  (5512, "01374926183"),
  (5560, "17274926183"),
  (5244, "76374926112");
  
INSERT INTO possui (idFarmacia, idSuprimento)
VALUES
  (1, 1),
  (1, 2),
  (3, 3);

INSERT INTO abastece (idFarmacia, idFornecedor)
VALUES
  (1, 1),
  (1, 2),
  (3, 3);

INSERT INTO contem (idMedicamento, idFarmacia)
VALUES
  (1, 1),
  (2, 2),
  (3, 3);