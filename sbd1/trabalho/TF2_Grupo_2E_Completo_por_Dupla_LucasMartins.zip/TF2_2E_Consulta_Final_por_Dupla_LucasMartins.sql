-- --------  << TF_Grupo_2_2E_lucasmartins >>  ----------
--
--                    SCRIPT DE CONSULTA
--
-- Data Criacao ...........: 12/05/2021
-- Autor(es) ..............: João Pedro Elias de Moura e Mateus Gomes do Nascimento 
-- Banco de Dados .........: MySQL 8.0.23
-- Base de Dados (nome) ...: TF_Grupo_2_2E_lucasmartins
--
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
-- 		   => 02 Visões
-- 		   => 04 Usuarios
--
-- ---------------------------------------------------------

USE TF_Grupo_2_2E_lucasmartins;

-- Consulta dos pacientes, médicos e receitas geradas por consultas feitas dentro de um intervalo de tempo especificado para identificar o médico que consultou certo paciente e qual receita foi gerada
SELECT R.idReceita, R.posologia, C.dtConsulta, M.idCrm, M.ufCrm, M.nomeMedico, P.cpfPaciente, P.nomePaciente  FROM RECEITA AS R
		INNER JOIN CONSULTA AS C ON C.idConsulta = R.idConsulta
		INNER JOIN MEDICO AS M ON M.idCrm = C.idCrm AND M.ufCrm = C.ufCrm
        INNER JOIN PACIENTE AS P ON P.cpfPaciente = C.cpfPaciente
        WHERE DATE(dtConsulta) > "2021-05-01" AND DATE(dtConsulta) < "2021-05-31"
        ORDER BY dtConsulta;

-- Consulta dos itens (medicamentos e insumos) que estão em baixa quantidade (menos que 13 unidades)
SELECT I.idItem, I.nomeItem, I.qtdItem, M.portaria, INS.categoriaInsumo  FROM ITEM AS I
	LEFT JOIN MEDICAMENTO AS M ON I.idItem = M.idItem
    LEFT JOIN INSUMO AS INS ON I.idItem = INS.idItem
    WHERE qtdItem < 13
    ORDER BY qtdItem;

-- Consulta para selecionar os pacientes e a data na qual receberam determinado medicamento de um atendimento realizado por um farmacêutico
CREATE OR REPLACE VIEW PACIENTES_ATENDIDOS
    (nomeItem, crfFarmaceutico, nomeFarmaceutico, cpfPaciente, nomePaciente, dtAtendimento)
AS
	SELECT I.nomeItem AS "Medicamento", F.crfFarmaceutico AS "CRF do Farmacêutico", F.nomeFarmaceutico AS "Nome do Farmacêutico", P.cpfPaciente AS "CPF do Paciente", P.nomePaciente AS "Nome do Paciente", A.dtAtendimento AS "Data do Atendimento" FROM coleta AS col
		INNER JOIN ITEM AS I ON col.idItem = I.idItem
		INNER JOIN FARMACEUTICO AS F ON F.crfFarmaceutico = col.crfFarmaceutico
		INNER JOIN ATENDIMENTO AS A ON A.crfFarmaceutico = F.crfFarmaceutico
		INNER JOIN PACIENTE AS
        P ON P.cpfPaciente = A.cpfPaciente
		WHERE nomeItem = "Dorflex"
		ORDER BY dtAtendimento;
        
-- Consulta para selecionar o recibo, o atendimento, o farmacêutico,  o paciente atendido e seu histórico de medicamentos a fim de ter um controle sobre todos os recibos gerados e seus autores
CREATE OR REPLACE VIEW RECIBOS_GERADOS
    (idRecibo, dtRecibo, proximaRetirada, idAtendimento, dtAtendimento, cpfPaciente, nomePaciente, crfFarmaceutico, nomeFarmaceutico, historicoMedicamento)
AS
    SELECT R.idRecibo AS "ID do Recibo", R.dtRecibo AS "Data do Recibo", R.proximaRetirada AS "Próxima Retirada", A.idAtendimento AS "ID do Atendimento", A.dtAtendimento AS "Data do Atendimento", P.cpfPaciente AS "CPF do Paciente", P.nomePaciente AS "Nome do Paciente", F.crfFarmaceutico AS "CRF do Farmacêutico", F.nomeFarmaceutico AS "Nome do Farmacêutico", hM.historicoMedicamento AS "Histórico de Medicamentos do Paciente" FROM RECIBO AS R
		INNER JOIN ATENDIMENTO AS A ON A.idAtendimento = R.idAtendimento
		INNER JOIN PACIENTE AS P ON P.cpfPaciente = A.cpfPaciente
		INNER JOIN FARMACEUTICO AS F ON F.crfFarmaceutico = A.crfFarmaceutico
		INNER JOIN historicoMedicamento AS hM ON hM.cpfPaciente = P.cpfPaciente
        ORDER BY dtRecibo;