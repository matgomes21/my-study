-- --------  << TF_Grupo_2_2E_lucasmartins >>  ----------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 12/05/2021
-- Autor(es) ..............: Jaime Juan de Castro Feliciano Damasceno, João Pedro Elias de Moura, Lucas Alexandre Fernandes Martins, Mateus Gomes do Nascimento e Matheus Afonso de Souza
-- Banco de Dados .........: MySQL 8.0.23
-- Base de Dados (nome) ...: TF_Grupo_2_2E_lucasmartins
--
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
-- 		   => 02 Visões
-- 		   => 04 Usuarios
--
-- ---------------------------------------------------------

USE TF_Grupo_2_2E_lucasmartins;

DROP TABLE coleta;
DROP TABLE solicita;
DROP TABLE possui;
DROP TABLE historicoMedicamento;
DROP TABLE RECIBO;
DROP TABLE ATENDIMENTO;
DROP TABLE PEDIDO;
DROP TABLE FARMACEUTICO;
DROP TABLE INSUMO;
DROP TABLE MEDICAMENTO;
DROP TABLE ITEM;
DROP TABLE RECEITA;
DROP TABLE CONSULTA;
DROP TABLE MEDICO;
DROP TABLE PACIENTE;

DROP USER 'administrador';
DROP USER 'funcionario';
DROP USER 'farmaceutico';
DROP USER 'medico';

DROP VIEW PACIENTES_ATENDIDOS;
DROP VIEW RECIBOS_GERADOS;