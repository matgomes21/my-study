-- --------  << TF_Grupo_2_2E_lucasmartins >>  ----------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 12/05/2021
-- Autor(es) ..............: Jaime Juan de Castro Feliciano Damasceno, João Pedro Elias de Moura, Lucas Alexandre Fernandes Martins, Mateus Gomes do Nascimento e Matheus Afonso de Souza
-- Banco de Dados .........: MySQL 8.0.23
-- Base de Dados (nome) ...: TF_Grupo_2_2E_lucasmartins
--
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
-- 		   => 02 Visões
-- 		   => 04 Usuarios
--
-- ---------------------------------------------------------

USE TF_Grupo_2_2E_lucasmartins;

-- USUARIOS
CREATE USER 'administrador' IDENTIFIED BY '123admin',
			'funcionario'   IDENTIFIED BY 'func123',
            'farmaceutico' 	IDENTIFIED BY 'farma123',
			'medico'		IDENTIFIED BY 'medico123';
            
-- PRIVILEGIOS
-- Todos privilégios cedidos ao administrador do posto
GRANT ALL PRIVILEGES ON TF_Grupo_2_2E_lucasmartins.* TO 'administrador' WITH GRANT OPTION;
GRANT SELECT ON TF_Grupo_2_2E_lucasmartins.PACIENTES_ATENDIDOS TO 'administrador';
GRANT SELECT ON TF_Grupo_2_2E_lucasmartins.RECIBOS_GERADOS TO 'administrador';

-- Usuário 'funcionario' poderá apenas verificar os dados das tabelas: 
-- 	-PACIENTE: para verificar se o mesmo consta na base de dados;
-- 	-CONSULTA: em caso de necessidade de verificar qual médico atendeu determinado paciente;
-- 	-ATENDIMENTO: caso seja necessidade de consultar a data que o paciente recebeu o medicamento. 
GRANT SELECT ON TF_Grupo_2_2E_lucasmartins.PACIENTE TO 'funcionario';
GRANT SELECT ON TF_Grupo_2_2E_lucasmartins.CONSULTA TO 'funcionario';
GRANT SELECT ON TF_Grupo_2_2E_lucasmartins.ATENDIMENTO TO 'funcionario';

-- Usuário 'farmaceutico' poderá consultar todos as tabelas da base de dados e inserir, atualizar e deletar de dados nas seguintes tabelas FARMACEUTICO, RECIBO, ATENDIMENTO, PEDIDO, ITEM, INSUMO, MEDICAMENTO e coleta, já que as outras tabelas não dizem respeito as funções do farmacêutico. 
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.FARMACEUTICO TO 'farmaceutico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.RECIBO TO 'farmaceutico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.ATENDIMENTO TO 'farmaceutico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.PEDIDO TO 'farmaceutico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.ITEM TO 'farmaceutico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.INSUMO TO 'farmaceutico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.MEDICAMENTO TO 'farmaceutico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.coleta TO 'farmaceutico';

-- Usuário 'medico' poderá consultar, inserir, atualizar e deletar tuplas apenas nas tabelas CONSULTA, PACIENTE e RECEITA, visto que para este usuário, apenas os dados dessa tabela fazem parte da sua atribuição. 
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.CONSULTA TO 'medico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.PACIENTE TO 'medico';
GRANT SELECT, INSERT, UPDATE, DELETE ON TF_Grupo_2_2E_lucasmartins.RECEITA TO 'medico';