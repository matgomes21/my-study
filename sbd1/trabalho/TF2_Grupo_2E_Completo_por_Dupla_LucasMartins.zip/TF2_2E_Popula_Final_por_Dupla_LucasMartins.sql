-- --------  << TF_Grupo_2_2E_lucasmartins >>  ----------
--
--                    SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 12/05/2021
-- Autor(es) ..............: Jaime Juan de Castro Feliciano Damasceno, João Pedro Elias de Moura, Lucas Alexandre Fernandes Martins, Mateus Gomes do Nascimento e Matheus Afonso de Souza
-- Banco de Dados .........: MySQL 8.0.23
-- Base de Dados (nome) ...: TF_Grupo_2_2E_lucasmartins
--
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
-- 		   => 02 Visões
-- 		   => 04 Usuarios
--
-- ---------------------------------------------------------

USE TF_Grupo_2_2E_lucasmartins;
    
INSERT INTO PACIENTE (cpfPaciente, numeroSus, cep, uf, cidade, bairro, logradouro, nomePaciente, dtNascimento, sexo)
	VALUES
		("01374926183", 5501, 72015595, "DF", "Brasília", "Taguatinga", "CSB 9 Lt 4 Apt 102", "Mateus Gomes do Nascimento", "2000-01-21", 'M'),
        ("72374926183", 5502, 71665595, "DF", "Brasília", "Águas Claras", "Av. Araucárias Rua 2", "Robson Nogueira Lima", "1988-03-12", 'M'),
        ("32374926183", 5503, 72115595, "SP", "São Paulo", "Liberdade", "Casa 4", "Juliana Fernandes da Silva", "2000-10-03", 'F'),
        ("44374926183", 5504, 72675595, "MG", "Uberlândia", "Centro", "Rua 2 Casa 3", "João Pedro Ferreira Gomes", "1995-02-22", 'M'),
        ("65374926183", 5505, 77865595, "DF", "Brasília", "Gama", "Rua 23 Casa 32", "Vinícius Souza Rocha", "1964-03-9", 'M'),
        ("49361491016", 1098, 72987398, "DF", "Brasília", "Asa norte", "Rua 23 Casa 1", "Matheus Afonso de Souza", "2001-12-9", 'M'),
        ("63985015007", 5658, 79908347, "DF", "Brasília", "Asa sul", "Rua 21 Casa 3", "Mateus Cunha Maia", "2000-01-9", 'M'),
        ("56280817016", 2345, 71987239, "RJ", "Niteroi", "setor de mansões", "QRC 17 23 Casa 12", "Marcelo Afonso de Souza", "1964-07-2", 'M'),
        ("91005296057", 2342, 75098123, "DF", "Brasília", "Gama", "Lote 23 Casa 1", "Andres Gomes Rocha", "1994-02-8", 'M'),
        ("33572658004", 5467, 77129377, "MG", "Uberlândia", "guaripi", "Bairro 233 lite 1", "Jennifer Santos Oliveira", "1988-03-9", 'f');
        
INSERT INTO MEDICO (idCrm, ufCrm, nomeMedico)
	VALUES
		(400911240, "DF", "Ana Teresa Borges Costa"),
        (687953050, "SP", "Felipe Gonçalves Lima"),
        (029027620, "MG", "Juliana Ferreira Gomes"),
        (401493580, "DF", "Vinícius de Moura Santos"),
        (033482950, "RJ", "Cátia Guerra da Paz"),
        (123432422, "RJ", "Rogerio da Silva Cardoso"),
        (546465474, "DF", "Milene de Sousa Rodolfo"),
        (123432154, "MG", "Fernando Vargas Teixeira"),
        (768675876, "RJ", "Eduard Alphonse Eric"),
        (435466576, "BH", "Rodvan Torebor Dilarvi Lissori");

INSERT INTO CONSULTA (dtConsulta, idCrm, ufCrm, cpfPaciente)
	VALUES
		("2021-05-09", 400911240, "DF", "01374926183"),
        ("2021-05-08", 687953050, "SP", "72374926183"),
        ("2021-04-22", 029027620, "MG", "32374926183"),
        ("2021-04-30", 401493580, "DF", "44374926183"),
        ("2021-05-03", 033482950, "RJ", "65374926183"),
        ("2021-05-01", 123432422, "RJ", "49361491016"),
        ("2021-07-18", 546465474, "DF", "63985015007"),
        ("2021-07-12", 123432154, "MG", "56280817016"),
        ("2021-02-23", 768675876, "RJ", "91005296057"),
        ("2021-02-21", 435466576, "BH", "33572658004");
	
INSERT INTO RECEITA (dtEmissao, tipo, validade, posologia, idConsulta)
	VALUES
		("2021-05-09", "normal", "2021-11-09", "Tomar duas vezes ao dia", 1),
        ("2021-05-08", "especial", "2022-06-15", "Tomar a cada duas horas", 2),
        ("2021-04-22", "normal", "2021-05-22", "Tomar antes de dormir", 3),
        ("2021-04-25", "normal", "2021-05-25", "Tomar a cada duas horas", 4),
        ("2021-05-03", "especial", "2021-08-03", "Tomar a cada oito horas", 5),
        ("2021-05-01", "normal", "2021-06-01", "Tomar a cada doze horas", 6),
        ("2021-07-18", "especial", "2021-08-18", "Tomar a cada dois dias", 7),
        ("2021-07-12", "normal", "2021-08-12", "Tomar ao acordar e ao ir dormir", 8),
        ("2021-02-23", "especial", "2021-02-23", "Tomar a cada oito horas", 9),
        ("2021-02-21", "normal", "2021-03-21", "Tomar a cada doze horas", 10);
    
INSERT INTO ITEM (nomeItem, qtdItem)
	VALUES
		("Álcool", 20),
        ("Dorflex", 33),
        ("Neosaldina", 12),
        ("Losartana", 7),
        ("Rivotril", 44),
        ("Predisin", 10),
        ("Gazua", 30),
        ("Cateter", 12),
        ("Luva", 50),
        ("Esparadrapo", 12),
        ("Bisturi", 13),
        ("Máscara", 15),
        ("Touca antiséptica", 22),
        ("Soro", 33),
        ("Tala", 23),
        ("Ladentrin", 44),
        ("Corsilno", 42),
        ("Madentroia", 12),
        ("Daforin", 42),
        ("Ecofilm", 26);

INSERT INTO MEDICAMENTO (idItem, portaria)
	VALUES
		(2, 202),
        (3, 203),
        (4, 204),
        (5, 205),
        (6, 206),
        (16, 222),
        (17, 324),
        (18, 456),
        (19, 345),
        (20, 456);
        
INSERT INTO INSUMO (idItem, categoriaInsumo)
	VALUES
		(1, "Limpeza"),
        (7, "Atendimento"),
        (8, "Experimento"),
        (9, "Atendimento"),
        (10, "Atendimento"),
        (11, "Tratamento"),
        (12, "Tratamento"),
        (13, "Tratamento"),
        (14, "Atendimento"),
        (15, "Atendimento");

INSERT INTO FARMACEUTICO (crfFarmaceutico, nomeFarmaceutico)
	VALUES
		("167635990", "Mautílio Mendes Cirilo"),
        ("809908970", "Luciene da Silva Nascimento"),
        ("002654890", "Caio Diogo Ferreira"),
        ("151125410", "Júlia Maria Vital"),
        ("005179550", "Giovana Perisse"),
        ("314532435", "Giorno Giovanni"),
        ("436547654", "Jonathan Jotaro"),
        ("234543255", "Robson Rodrigues"),
        ("324532456", "Joui Jouki"),
        ("435756772", "Clarisse Leonarda");
        
INSERT INTO PEDIDO (dtPedido, quantidade, crfFarmaceutico)
	VALUES
		("2021-05-09", 2, "167635990"),
        ("2021-05-08", 1, "809908970"),
        ("2021-04-22", 1, "002654890"),
        ("2021-04-30", 3, "151125410"),
        ("2021-05-03", 1, "005179550"),
        ("2021-06-01", 2, "314532435"),
        ("2021-07-12", 3, "436547654"),
        ("2021-12-23", 5, "234543255"),
        ("2021-08-13", 4, "324532456"),
        ("2021-09-12", 2, "435756772");

INSERT INTO ATENDIMENTO (dtAtendimento, cpfPaciente, crfFarmaceutico)
	VALUES
		("2021-05-09", "01374926183", "167635990"),
        ("2021-05-08", "72374926183", "809908970"),
        ("2021-04-22", "32374926183", "002654890"),
        ("2021-04-30", "44374926183", "151125410"),
        ("2021-05-03", "65374926183", "005179550"),
        ("2021-06-30", "49361491016", "314532435"),
        ("2021-06-22", "63985015007", "436547654"),
        ("2021-02-11", "56280817016", "234543255"),
        ("2021-03-23", "91005296057", "324532456"),
        ("2021-01-13", "33572658004", "435756772");
        
INSERT INTO RECIBO (dtRecibo, proximaRetirada, idAtendimento)
	VALUES
		("2021-05-09", "2021-06-09", 1),
        ("2021-05-08", "2021-06-08", 2),
        ("2021-04-22", "2021-05-22", 3),
        ("2021-04-30", "2021-05-30", 4),
        ("2021-05-03", "2021-06-03", 5),
        ("2021-06-11", "2021-07-11", 6),
        ("2021-01-22", "2021-02-22", 7),
        ("2021-06-13", "2021-07-13", 8),
        ("2021-02-23", "2021-03-23", 9),
        ("2021-01-13", "2021-02-13", 10);

INSERT INTO historicoMedicamento (cpfPaciente, historicoMedicamento)
	VALUES
		("01374926183", "Dorflex"),
        ("72374926183", "Neosaldina"),
        ("32374926183", "Neosaldina, Dorflex"),
        ("44374926183", "Rivotril"),
        ("65374926183", "Ladentrin, Ecofilm"),
        ("49361491016", "Rivotril, Ecofilm"),
        ("63985015007", "Ecofilm, Ladentrin"),
        ("56280817016", "Rivotril, Dorflex"),
        ("91005296057", "Ecofilm, Dorflex"),
        ("33572658004", "Rivotril, Ecofilm");
        
INSERT INTO possui (idReceita, idItem)
	VALUES
		(1, 1),
        (2, 2),
        (3, 3),
        (4, 4),
        (5, 5),
        (6, 6),
        (7, 7),
        (8, 8),
        (9, 9),
        (10, 10);

INSERT INTO solicita (idItem, idPedido)
	VALUES
		(1, 1),
        (2, 2),
        (3, 3),
        (4, 4),
        (5, 5),
        (6, 6),
        (7, 7),
        (8, 8),
        (9, 9),
        (10, 10);
        
INSERT INTO coleta (crfFarmaceutico, idItem)
	VALUES
		("167635990", 1),
        ("809908970", 2),
        ("002654890", 2),
        ("151125410", 2),
        ("005179550", 5),
        ("314532435", 6),
        ("436547654", 6),
        ("234543255", 7),
        ("324532456", 7),
        ("435756772", 9);