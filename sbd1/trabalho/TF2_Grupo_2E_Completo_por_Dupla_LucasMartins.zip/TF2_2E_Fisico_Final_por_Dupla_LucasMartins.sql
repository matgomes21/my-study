-- --------  << TF_Grupo_2_2E_lucasmartins >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 12/05/2021
-- Autor(es) ..............: Jaime Juan de Castro Feliciano Damasceno, João Pedro Elias de Moura, Lucas Alexandre Fernandes Martins, Mateus Gomes do Nascimento e Matheus Afonso de Souza
-- Banco de Dados .........: MySQL 8.0.23
-- Base de Dados (nome) ...: TF_Grupo_2_2E_lucasmartins
--
--
-- PROJETO => 01 Base de Dados
--         => 15 Tabelas
-- 		   => 02 Visões
-- 		   => 04 Usuarios
--
-- ---------------------------------------------------------

CREATE DATABASE
	IF NOT EXISTS TF_Grupo_2_2E_lucasmartins;
    
USE TF_Grupo_2_2E_lucasmartins;

CREATE TABLE PACIENTE (
    cpfPaciente VARCHAR(11) NOT NULL,
    numeroSus INT NOT NULL,
    cep INT NOT NULL,
    uf VARCHAR(2) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    logradouro VARCHAR(100) NOT NULL,
    nomePaciente VARCHAR(100) NOT NULL,
    dtNascimento DATE NOT NULL,
    sexo ENUM('F','M') NOT NULL,
    
    CONSTRAINT PACIENTE_PK PRIMARY KEY (cpfPaciente),
    
    CONSTRAINT PACIENTE_UK UNIQUE KEY (numeroSus)
)ENGINE=InnoDB;

CREATE TABLE MEDICO (
    idCrm INT NOT NULL,
    ufCrm VARCHAR(2) NOT NULL,
    nomeMedico VARCHAR(100) NOT NULL,
    
    CONSTRAINT MEDICO_PK PRIMARY KEY (idCrm, ufCrm)
)ENGINE=InnoDB;

CREATE TABLE CONSULTA (
    idConsulta INT NOT NULL AUTO_INCREMENT,
    dtConsulta DATE NOT NULL,
    idCrm INT NOT NULL,
    ufCrm VARCHAR(2) NOT NULL,
    cpfPaciente VARCHAR(11) NOT NULL,
    
    CONSTRAINT CONSULTA_PK PRIMARY KEY (idConsulta),
    
    CONSTRAINT CONSULTA_MEDICO_FK FOREIGN KEY (idCrm, ufCrm)
		REFERENCES MEDICO(idCrm,ufCrm)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
	CONSTRAINT CONSULTA_PACIENTE_FK FOREIGN KEY (cpfPaciente)
		REFERENCES PACIENTE(cpfPaciente)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE RECEITA (
    idReceita INT NOT NULL AUTO_INCREMENT,
    dtEmissao DATE NOT NULL,
    tipo VARCHAR(100) NOT NULL,
    validade DATE NOT NULL,
    posologia VARCHAR(100) NOT NULL,
    idConsulta INT NOT NULL,
    
    CONSTRAINT RECEITA_PK PRIMARY KEY (idReceita),
    
    CONSTRAINT RECEITA_CONSULTA_FK FOREIGN KEY (idConsulta)
		REFERENCES CONSULTA(idConsulta)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE ITEM (
    idItem INT NOT NULL AUTO_INCREMENT,
    nomeItem VARCHAR(100) NOT NULL,
    qtdItem INT NOT NULL,
    
    CONSTRAINT ITEM_PK PRIMARY KEY (idItem)
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE MEDICAMENTO (
    idItem INT NOT NULL,
    portaria INT NOT NULL,
    
    CONSTRAINT MEDICAMENTO_PK PRIMARY KEY (idItem),
    
    CONSTRAINT MEDICAMENTO_ITEM_FK FOREIGN KEY (idItem)
		REFERENCES ITEM(idItem)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE INSUMO (
    idItem INT NOT NULL,
    categoriaInsumo VARCHAR(100) NOT NULL,
    
    CONSTRAINT INSUMO_PK PRIMARY KEY (idItem),
    
    CONSTRAINT INSUMO_ITEM_FK FOREIGN KEY (idItem)
		REFERENCES ITEM(idItem)
		ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE FARMACEUTICO (
    crfFarmaceutico VARCHAR(9) NOT NULL,
    nomeFarmaceutico VARCHAR(100) NOT NULL,
    
    CONSTRAINT FARMACEUTICO_PK PRIMARY KEY (crfFarmaceutico)
)ENGINE=InnoDB;

CREATE TABLE PEDIDO (
    idPedido INT NOT NULL AUTO_INCREMENT,
    dtPedido DATE NOT NULL,
    quantidade INT NOT NULL,
    crfFarmaceutico VARCHAR(9) NOT NULL,
    
    CONSTRAINT PEDIDO_PK PRIMARY KEY (idPedido),
    
    CONSTRAINT PEDIDO_FARMACEUTICO_FK FOREIGN KEY (crfFarmaceutico)
		REFERENCES FARMACEUTICO (crfFarmaceutico)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE ATENDIMENTO (
    idAtendimento INT NOT NULL AUTO_INCREMENT,
    dtAtendimento DATE NOT NULL,
    cpfPaciente VARCHAR(11) NOT NULL,
    crfFarmaceutico VARCHAR(9) NOT NULL,
    
    CONSTRAINT ATENDIMENTO_PK PRIMARY KEY (idAtendimento),
    
    CONSTRAINT ATENDIMENTO_PACIENTE_FK FOREIGN KEY (cpfPaciente)
		REFERENCES PACIENTE(cpfPaciente)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
	CONSTRAINT ATENDIMENTO_FARMACEUTICO_FK FOREIGN KEY (crfFarmaceutico)
		REFERENCES FARMACEUTICO(crfFarmaceutico)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE RECIBO (
    idRecibo INT NOT NULL AUTO_INCREMENT,
    dtRecibo DATE NOT NULL,
    proximaRetirada DATE NOT NULL,
    idAtendimento INT NOT NULL,
    
    CONSTRAINT RECIBO_PK PRIMARY KEY (idRecibo),
    
    CONSTRAINT RECIBO_ATENDIMENTO_FK FOREIGN KEY (idAtendimento)
		REFERENCES ATENDIMENTO (idAtendimento)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB AUTO_INCREMENT=1;

CREATE TABLE historicoMedicamento (
    cpfPaciente VARCHAR(11) NOT NULL,
    historicoMedicamento VARCHAR(100) NOT NULL,
    
    CONSTRAINT historicoMedicamento_PACIENTE_FK FOREIGN KEY (cpfPaciente)
		REFERENCES PACIENTE (cpfPaciente)
        ON DELETE CASCADE
        ON UPDATE CASCADE
)ENGINE=InnoDB;

CREATE TABLE possui (
    idReceita INT NOT NULL,
    idItem INT NOT NULL,
    
    CONSTRAINT possui_RECEITA_FK FOREIGN KEY (idReceita)
		REFERENCES RECEITA (idReceita)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
	CONSTRAINT possui_ITEM_FK FOREIGN KEY (idItem)
		REFERENCES ITEM(idItem)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE solicita (
    idItem INT NOT NULL,
    idPedido INT NOT NULL,
    
    CONSTRAINT solicita_ITEM_FK FOREIGN KEY (idItem)
		REFERENCES ITEM (idItem)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
	CONSTRAINT solicita_PEDIDO_FK FOREIGN KEY (idPedido)
		REFERENCES PEDIDO(idPedido)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB;

CREATE TABLE coleta (
    crfFarmaceutico VARCHAR(9) NOT NULL,
    idItem INT NOT NULL,
    
    CONSTRAINT coleta_FARMACEUTICO_FK FOREIGN KEY (crfFarmaceutico)
		REFERENCES FARMACEUTICO (crfFarmaceutico)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT,
	CONSTRAINT coleta_ITEM_FK FOREIGN KEY (idItem)
		REFERENCES ITEM(idItem)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
)ENGINE=InnoDB;